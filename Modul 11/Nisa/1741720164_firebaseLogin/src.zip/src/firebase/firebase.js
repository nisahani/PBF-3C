import firebase from "firebase/app";
import "firebase/auth";
import "firebase/firestore";

const firebaseConfig = {
    apiKey: "AIzaSyDhoDtC8nkm07dy4AQduWTbnLxFy9cD9G8",
    authDomain: "login-f9727.firebaseapp.com",
    databaseURL: "https://login-f9727.firebaseio.com",
    projectId: "login-f9727",
    storageBucket: "login-f9727.appspot.com",
    messagingSenderId: "697331420575",
    appId: "1:697331420575:web:8ea5b30ec44195ecd681aa",
    measurementId: "G-67P4HQQ6ES"
};

export const myFirebase = firebase.initializeApp(firebaseConfig);
const baseDb = myFirebase.firestore();
export const db = baseDb;